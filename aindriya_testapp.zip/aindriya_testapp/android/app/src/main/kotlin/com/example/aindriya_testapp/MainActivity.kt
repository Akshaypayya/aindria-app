package com.example.aindriya_testapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
