
import 'package:aindriya_testapp/view/home_page.dart';
import 'package:aindriya_testapp/view/profile_page.dart';
import 'package:aindriya_testapp/view/shop_screen.dart';
import 'package:aindriya_testapp/view/notification.dart';
import 'package:flutter/material.dart';

class Navigationpage extends StatefulWidget {
  Navigationpage({Key? key}) : super(key: key);

  @override
  State<Navigationpage> createState() => _NavigationpageState();
}

class _NavigationpageState extends State<Navigationpage> {

  int index = 0;
 final screens = [
     HomePage(),
     ShopScreen(),
   AppNotification(),
    ProfilePage(),
  ];


  @override
  Widget build(BuildContext context) => Scaffold(
      body: screens[index],
      bottomNavigationBar: NavigationBarTheme(
        data: NavigationBarThemeData(
          height: 60,

          indicatorColor: Colors.white,
          labelTextStyle: MaterialStateProperty.all(
            const TextStyle(fontSize: 14,fontWeight: FontWeight.w500,color: Colors.white),
          )
        ),
        child: ClipRRect(
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(30.0),
            topRight: Radius.circular(30.0),
          ),
          child: NavigationBar(
            labelBehavior: NavigationDestinationLabelBehavior.onlyShowSelected,
            selectedIndex: index,
            animationDuration: const Duration(seconds:3),
            backgroundColor: Color(0xff5077DD),
            onDestinationSelected: (index) =>
            setState(() => this.index=index),
            destinations: const [
              NavigationDestination(
                selectedIcon: Icon(Icons.home),
                icon: Icon(Icons.home_outlined),
                label: 'Home',
              ),
              NavigationDestination(
                selectedIcon: Icon(Icons.grid_view_rounded),
                icon: Icon(Icons.grid_view_outlined),
                label: 'Explore',
              ),
              NavigationDestination(
                selectedIcon: Icon(Icons.card_giftcard_outlined),
                icon: Icon(Icons.card_giftcard_rounded),
                label: 'Notification',
              ),
              NavigationDestination(
                selectedIcon: Icon(Icons.person),
                icon: Icon(Icons.person_outlined),
                label: 'Profile',
              ),
            ],
          ),
        ),
      ),
    );
  }
