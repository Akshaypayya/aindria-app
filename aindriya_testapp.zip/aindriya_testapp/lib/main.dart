import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:aindriya_testapp/view/login.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  final Color primaryColor = const Color(0xffECECEC);
  final Color accentColor = const Color(0xffFFFFFF);

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      theme: ThemeData(
        primaryColor: primaryColor,
        scaffoldBackgroundColor: Colors.grey.shade100,
        colorScheme: ColorScheme.fromSwatch(primarySwatch: Colors.grey).copyWith(secondary: accentColor,),
      ),
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      home:  LoginPage(title: 'Flutter Sample'),
    );
  }
}
