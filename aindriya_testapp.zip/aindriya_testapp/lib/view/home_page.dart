import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  HomePage({Key? key}) : super(key: key);

  var size, height, width;
  List<String> images = [
    "assets/images/antara.png",
    "assets/images/ashoka.png",
    "assets/images/niha.png",
     "assets/images/zudio.png"
  ];

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    height = size.height;
    width = size.width;
    return Center(
        child: Container(
        decoration:  BoxDecoration(
        gradient: LinearGradient(
        begin: Alignment.topRight,
        end: Alignment.bottomLeft,
        stops: [0.9,1.2],
        colors: [
          Theme.of(context).primaryColor,
          Theme.of(context).colorScheme.secondary,
        ])),
    child: Scaffold(
    backgroundColor: Colors.transparent,
    body: SingleChildScrollView(
    child: SafeArea(
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 20,vertical: 22),
        child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              CircleAvatar(
                radius: 30,
               child: Image.asset("assets/images/dp.png",height: 65,width: 65),
                backgroundColor: Color(0xffFFFFFF),
              ),
              SizedBox(width: 10),
              Container(
                height: 50,
                width: 249,
                decoration:  BoxDecoration(
                  gradient: LinearGradient(
                      begin: Alignment(0.0, 0.0),
                      end: Alignment(1.0, 0.0),
                      stops: [0.1,0.5],
                      colors: [
                        Color(0xffFFFFFF),
                        Color(0xffFFFFFF),
                      ]),
                  borderRadius: BorderRadius.all(const Radius.circular(13.0)),
                ),
                  child: Padding(
                    padding: const EdgeInsets.all(5.0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                        Icon(Icons.gps_fixed_outlined,color:Color(0xff4956B2),),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("Kakkanad",
                                style: TextStyle(
                                  fontFamily: 'Roboto',
                                  fontWeight: FontWeight.w500,
                                  fontStyle: FontStyle.normal,
                                  fontSize: 16,)),
                              Text("Chittethukara, Kerala 652 565",
                                  style: TextStyle(
                                    fontFamily: 'Roboto',
                                    fontWeight: FontWeight.w300,
                                    fontStyle: FontStyle.normal,
                                    fontSize: 12,)),
                            ],
                          ),
                          Icon(Icons.arrow_drop_down_sharp,size: 28,)
                          ]
                    )
                  )
              ),
              ShaderMask(
                blendMode: BlendMode.srcIn,
                shaderCallback: (Rect bounds) => RadialGradient(
                  center: Alignment.topCenter,
                  stops: [0.6, 0.1],
                  colors: [
                    Color(0xff3F48BF),
                    Color(0xff4172E0),
                  ],
                ).createShader(bounds),
                child: Icon(
                  Icons.notifications_sharp,
                  size: 50,
                ),
              ),
            ],
          ),
          SizedBox(height: 20),
          Container(
              height: 46,
              width: 388,
              decoration:  BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment(0.0, 0.0),
                    end: Alignment(1.0, 0.0),
                    stops: [0.1,0.5],
                    colors: [
                      Color(0xffFFFFFF),
                      Color(0xffFFFFFF),
                    ]),
                borderRadius: BorderRadius.all(const Radius.circular(13.0)),
              ),
              child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Search Shop Here", style: TextStyle(
                    fontFamily: 'Roboto',
                    color: Color(0xff000000),
                    fontWeight: FontWeight.w200,
                    fontStyle: FontStyle.normal,
                    fontSize: 18,)),
                  Icon(Icons.search,color: Color(0xff000000),size: 40),
                ],
              ),
              )
          ),
          SizedBox(height: 18),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                height: 140,
                width: 172,
                decoration:  BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(20)),
                    gradient: LinearGradient(
                        begin: Alignment.topRight,
                        end: Alignment.bottomLeft,
                        tileMode: TileMode.mirror,
                        stops: [0.0,1.0,1.1],
                        colors: [
                        Color(0xff3F46BD),
                    Color(0xff417DE8),
                           Color(0xff00ACFF),
                        ])),
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Text("Total Coin Balance",
                                textAlign: TextAlign.start,
                                style: TextStyle(
                              fontFamily: 'Roboto',
                              color: Color(0xffFFFFFF),
                              fontWeight: FontWeight.w300,
                              fontStyle: FontStyle.normal,
                              fontSize: 12,)),
                          ),

                      Row(
                        children: [
                          Text("14,325",style: TextStyle(
                            fontFamily: 'Roboto',
                            color: Color(0xffFFFFFF),
                            fontWeight: FontWeight.w700,
                            fontStyle: FontStyle.normal,
                            fontSize: 29,)),
                          SizedBox(width: 20,),
                          Image.asset("assets/images/coin.png",height: 24,width: 24,fit: BoxFit.fill,),
                        ],
                      ),  ],
                      ),
                      SizedBox(height: 10,),
                      Divider(color: Color(0xffFFFFFF),height: 1,),
                      SizedBox(height: 10,),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,

                            children: [
                              Text("Redeemable",style: TextStyle(
                                fontFamily: 'Roboto',
                                color: Color(0xffFFFFFF),
                                fontWeight: FontWeight.w300,
                                fontStyle: FontStyle.normal,
                                fontSize: 12,)),
                              Text("Expired",style: TextStyle(
                                fontFamily: 'Roboto',
                                color: Color(0xffFFFFFF),
                                fontWeight: FontWeight.w300,
                                fontStyle: FontStyle.normal,
                                fontSize: 12,))
                            ],
                          ),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text("9216",style: TextStyle(
                                fontFamily: 'Roboto',
                                color: Color(0xffFFFFFF),
                                fontWeight: FontWeight.w700,
                                fontStyle: FontStyle.normal,
                                fontSize: 16,)),

                              Image.asset("assets/images/coin.png",height: 13,width: 13,fit: BoxFit.fill,),

                            ],
                          ),
                          Row(
                            children: [
                              Text("6542",style: TextStyle(
                                fontFamily: 'Roboto',
                                color: Color(0xffFFFFFF),
                                fontWeight: FontWeight.w700,
                                fontStyle: FontStyle.normal,
                                fontSize: 16,)),

                              Image.asset("assets/images/coin.png",height: 13,width: 13,fit: BoxFit.fill,),
                            ],
                          ),
                        ],
                      ),
                        ],
                      )
                    ],
                  ),
                ),
              ),
              Container(
                height: 140,
                width: 172,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(20)),
                  color: Color(0xffFFFFFF),
                ),


                child: Padding(
                  padding:EdgeInsets.only(left: 37.53,top: 21,right: 37.53),
                  child: Column(
                    children: [
                      Container(
                        height: 82,
                        width: 87.93,
                        decoration:  BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            gradient: LinearGradient(
                                begin: Alignment.topRight,
                                end: Alignment.bottomRight,
                                stops: [0.2,2.1],
                                colors: [
                                  Color(0xff3F46BD),
                                  Color(0xff417DE8),
                                ])),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text("||||",
                                style: TextStyle(
                                  fontFamily: 'Roboto',
                                  color: Color(0xffFFFFFF),
                                  fontWeight: FontWeight.w700,
                                  fontStyle: FontStyle.normal,
                                  fontSize: 22,)),
                          ],
                        ),
                      ),
                      Padding(
                        padding:  EdgeInsets.all(5.0),
                        child: Text('Add New Bill',
                            style: TextStyle(
                              fontFamily: 'Inter',
                              color: Color(0xff4060D1),
                              fontWeight: FontWeight.w400,
                              fontStyle: FontStyle.normal,
                              fontSize: 12,)),
                      ),
                    ],

                  ),
                ),
              )
            ],
          ),
          SizedBox(height: 32,),
          Image.asset("assets/images/superpromo.png",height: 175,width: 388,fit: BoxFit.fill,),
          SizedBox(height: 20,),
          Column(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Container(
                    child: Text("Top Categories",
                        style: TextStyle(
                          fontFamily: 'Inter',
                          color: Color(0xff000000),
                          fontWeight: FontWeight.w600,
                          fontStyle: FontStyle.normal,
                          fontSize: 20,)),

                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Column(
                children: [
                  Container(
                    height: 62,
                    width: 62,
                    decoration:  BoxDecoration(
                      gradient: LinearGradient(
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                          stops: [0.0,0.6],
                          colors: [
                            Color(0xff3F46BD),
                            Color(0xff417DE8),
                          ]),
                      borderRadius: BorderRadius.all(const Radius.circular(13.0)),
                    ),
                    child:Image.asset("assets/images/textiles.png",height: 25,width: 20),
                  ),
                  SizedBox(height: 10,),
                  Text("Textiles",style: TextStyle(
                    fontFamily: 'Roboto',
                    color: Color(0xff000000),
                    fontWeight: FontWeight.w300,
                    fontStyle: FontStyle.normal,
                    fontSize: 12,))
                ],
              ),
              Column(
                children: [
                  Container(
                    height: 62,
                    width: 62,
                    decoration:  BoxDecoration(
                      gradient: LinearGradient(
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                          stops: [0.0,0.6],
                          colors: [
                            Color(0xff3F46BD),
                            Color(0xff417DE8),
                          ]),
                      borderRadius: BorderRadius.all(const Radius.circular(13.0)),
                    ),
                    child:Image.asset("assets/images/jewellery.png",height: 25,width: 20),
                  ),
                  SizedBox(height: 10,),
                  Text("Jewellery",style: TextStyle(
                    fontFamily: 'Roboto',
                    color: Color(0xff000000),
                    fontWeight: FontWeight.w300,
                    fontStyle: FontStyle.normal,
                    fontSize: 12,)),
                ],
              ),
              Column(
                children: [
                  Container(
                    height: 62,
                    width: 62,
                    decoration:  BoxDecoration(
                      gradient: LinearGradient(
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                          stops: [0.0,0.6],
                          colors: [
                            Color(0xff3F46BD),
                            Color(0xff417DE8),
                          ]),
                      borderRadius: BorderRadius.all(const Radius.circular(13.0)),
                    ),
                    child:Image.asset("assets/images/furniture.png",height: 25,width: 20),
                  ),
                  SizedBox(height: 10,),
                  Text("Furniture",style: TextStyle(
                    fontFamily: 'Roboto',
                    color: Color(0xff000000),
                    fontWeight: FontWeight.w300,
                    fontStyle: FontStyle.normal,
                    fontSize: 12,))
                ],
              ),
              Column(
                children: [
                  Container(
                    height: 62,
                    width: 62,
                    decoration:  BoxDecoration(
                      gradient: LinearGradient(
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                          stops: [0.0,0.6],
                          colors: [
                            Color(0xff3F46BD),
                            Color(0xff417DE8),
                          ]),
                      borderRadius: BorderRadius.all(const Radius.circular(13.0)),
                    ),
                    child:Image.asset("assets/images/supermarket.png",height: 25,width: 20),
                  ),
                  SizedBox(height: 10,),
                  Text("Supermarket",style: TextStyle(
                    fontFamily: 'Roboto',
                    color: Color(0xff000000),
                    fontWeight: FontWeight.w300,
                    fontStyle: FontStyle.normal,
                    fontSize: 12,))
                ],
              ),
              Column(
                children: [
                  Container(
                    height: 62,
                    width: 62,
                    decoration:  BoxDecoration(
                      gradient: LinearGradient(
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                          stops: [0.0,0.6],
                          colors: [
                            Color(0xff3F46BD),
                            Color(0xff417DE8),
                          ]),
                      borderRadius: BorderRadius.all(const Radius.circular(13.0)),
                    ),
                    child:Image.asset("assets/images/restaurant.png",height: 25,width: 20),
                  ),
                  SizedBox(height: 10,),
                  Text("Restaurant",style: TextStyle(
                    fontFamily: 'Roboto',
                    color: Color(0xff000000),
                    fontWeight: FontWeight.w300,
                    fontStyle: FontStyle.normal,
                    fontSize: 12,))
                ],
              ),
            ],
          ),
          SizedBox(height: 30,),
          Column(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Container(
                    child: Text("Featured Shops",
                        style: TextStyle(
                          fontFamily: 'Roboto',
                          color: Color(0xff000000),
                          fontWeight: FontWeight.w600,
                          fontStyle: FontStyle.normal,
                          fontSize: 22,)),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 15,),
                //
                //       Container(
                //         width: 90,
                //         height: 30,
                //         decoration:  BoxDecoration(
                //             gradient: LinearGradient(
                //                 begin: Alignment.centerLeft,
                //                 end: Alignment.centerRight,
                //                 stops: [0.0,0.6],
                //                 colors: [
                //                   Color(0xffF2709C),
                //                   Color(0xffFF9472),
                //                 ])),
                //         child: Text("Trending",style: TextStyle(
                //           fontFamily: 'Roboto',
                //           color: Colors.white,
                //           fontWeight: FontWeight.w500,
                //           fontStyle: FontStyle.normal,
                //           fontSize: 22,)),
                //       ),
                //     ],
                // ),
                Column(
                  children: [
                    Text("Zudio Shoppee", style: TextStyle(
                      fontFamily: 'Roboto',
                      color: Color(0xff000000),
                      fontWeight: FontWeight.w500,
                      fontStyle: FontStyle.normal,
                      fontSize: 18,)),

                Row(
                    children: [
                      Image.asset("assets/images/textiles.png",height: 125,width: 120,color: Color(0xff7D81EA),),
                      Text("Textile", style: TextStyle(
                        fontFamily: 'Roboto',
                        color: Color(0xff000000),
                        fontWeight: FontWeight.w300,
                        fontStyle: FontStyle.normal,
                        fontSize: 16,)),
                    ]),
                Row(
                  children: [
                    Image.asset("assets/images/star.png",height: 30,width: 20,),
                    Image.asset("assets/images/star.png",height: 30,width: 20,),
                    Image.asset("assets/images/star.png",height: 30,width: 20,),
                    Image.asset("assets/images/star.png",height: 30,width: 20,),
                    Image.asset("assets/images/star.png",height: 30,width: 20,),
                    Text("(125)", style: TextStyle(
                      fontFamily: 'Roboto',
                      color: Color(0xff000000),
                      fontWeight: FontWeight.w300,
                      fontStyle: FontStyle.normal,
                      fontSize: 15,))
                  ],
                ),
                  ],
                ),


          SizedBox(height: 15,),
          Column(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Container(
                    child: Text("Featured Shops",
                        style: TextStyle(
                          fontFamily: 'Roboto',
                          color: Color(0xff000000),
                          fontWeight: FontWeight.w600,
                          fontStyle: FontStyle.normal,
                          fontSize: 22,)),
                  ),
                ),
              ),
            ],
          ),
    ])
    ))))));
  }
}
