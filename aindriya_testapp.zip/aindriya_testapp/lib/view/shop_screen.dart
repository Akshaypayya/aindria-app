import 'package:flutter/material.dart';

class ShopScreen extends StatefulWidget {
  const ShopScreen({Key? key}) : super(key: key);

  @override
  State<ShopScreen> createState() => _ShopScreenState();
}

class _ShopScreenState extends State<ShopScreen> {
  var size, height, width;

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    height = size.height;
    width = size.width;
    return Container(
        decoration: BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
                stops: [
              0.5,
              1.2
            ],
                colors: [
              Theme.of(context).primaryColor,
              Theme.of(context).colorScheme.secondary,
            ])),
        child: Scaffold(
            backgroundColor: Colors.transparent,
            body: SingleChildScrollView(
                child: Column(children: [
              Image.asset("assets/images/graffjewellers.png",
                  height: 269, width: 428),
              SizedBox(
                height: 20,
              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.0),
                child: Container(
                    height: 255,
                    width: 400,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                          begin: Alignment(0.0, 0.0),
                          end: Alignment(1.0, 0.0),
                          stops: [
                            0.1,
                            0.5
                          ],
                          colors: [
                            Colors.white70,
                            Colors.white70,
                          ]),
                      borderRadius:
                          BorderRadius.all(const Radius.circular(13.0)),
                    ),
                    child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  children: [
                                    Text("Graff Jewellers",
                                        style: TextStyle(
                                          fontFamily: 'Roboto',
                                          color: Color(0xff000000),
                                          fontWeight: FontWeight.w600,
                                          fontStyle: FontStyle.normal,
                                          fontSize: 24,
                                        )),
                                    Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Image.asset(
                                            "assets/images/jewellery.png",
                                            height: 12,
                                            width: 14,
                                            color: Color(0xff7D81EA),
                                          ),
                                          SizedBox(
                                            width: 5,
                                          ),
                                          Text("Jewellery",
                                              style: TextStyle(
                                                fontFamily: 'Roboto',
                                                color: Color(0xff000000),
                                                fontWeight: FontWeight.w300,
                                                fontStyle: FontStyle.normal,
                                                fontSize: 18,
                                              )),
                                        ]),
                                    Row(
                                      children: [
                                        Image.asset(
                                          "assets/images/star.png",
                                          height: 30,
                                          width: 15,
                                        ),
                                        Image.asset(
                                          "assets/images/star.png",
                                          height: 30,
                                          width: 15,
                                        ),
                                        Image.asset(
                                          "assets/images/star.png",
                                          height: 30,
                                          width: 15,
                                        ),
                                        Image.asset(
                                          "assets/images/star.png",
                                          height: 30,
                                          width: 15,
                                        ),
                                        Image.asset(
                                          "assets/images/star.png",
                                          height: 30,
                                          width: 15,
                                        ),
                                        Text("742 Ratings (125)",
                                            style: TextStyle(
                                              fontFamily: 'Roboto',
                                              color: Color(0xff000000),
                                              fontWeight: FontWeight.w300,
                                              fontStyle: FontStyle.normal,
                                              fontSize: 17,
                                            ))
                                      ],
                                    ),
                                  ],
                                ),
                                Container(
                                  height: 50,
                                  width: 60,
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                        begin: Alignment(0.0, 0.0),
                                        end: Alignment(1, -0.003),
                                        stops: [
                                          0.1,
                                          0.9
                                        ],
                                        colors: [
                                          Colors.white,
                                          Colors.white,
                                        ]),
                                    borderRadius: BorderRadius.all(
                                        const Radius.circular(13.0)),
                                  ),
                                  child: Image.asset(
                                    "assets/images/heart.png",
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Row(
                                  children: [
                                    Image.asset(
                                      "assets/images/direction.png",
                                    ),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Text('Location',
                                        style: TextStyle(
                                          fontFamily: 'Roboto',
                                          color: Color(0xffFF4022),
                                          fontWeight: FontWeight.w400,
                                          fontStyle: FontStyle.normal,
                                          fontSize: 22,
                                        )),
                                  ],
                                ),
                                Text(
                                    '2nd Floor, Grand Mall, Center Square \nBangalore, Karnataka 654 555 ',
                                    style: TextStyle(
                                      fontFamily: 'Roboto',
                                      color: Colors.black,
                                      fontWeight: FontWeight.w400,
                                      fontStyle: FontStyle.normal,
                                      fontSize: 14,
                                    )),
                              ],
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Row(
                                  children: [
                                    Image.asset(
                                      "assets/images/call.png",
                                    ),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Text('Contact',
                                        style: TextStyle(
                                          fontFamily: 'Roboto',
                                          color: Color(0xff00930F),
                                          fontWeight: FontWeight.w400,
                                          fontStyle: FontStyle.normal,
                                          fontSize: 22,
                                        )),
                                  ],
                                ),
                                Text('+91 9565521331, +91 9546542133',
                                    style: TextStyle(
                                      fontFamily: 'Roboto',
                                      color: Colors.black,
                                      fontWeight: FontWeight.w400,
                                      fontStyle: FontStyle.normal,
                                      fontSize: 14,
                                    )),
                              ],
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Row(
                                  //  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Image.asset(
                                      "assets/images/clock.png",
                                    ),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Text('Opening',
                                        style: TextStyle(
                                          fontFamily: 'Roboto',
                                          color: Color(0xff7D81EA),
                                          fontWeight: FontWeight.w400,
                                          fontStyle: FontStyle.normal,
                                          fontSize: 22,
                                        )),
                                  ],
                                ),
                                Text('09:30 am - 06:00',
                                    style: TextStyle(
                                      fontFamily: 'Roboto',
                                      color: Colors.black,
                                      fontWeight: FontWeight.w400,
                                      fontStyle: FontStyle.normal,
                                      fontSize: 14,
                                    )),
                              ],
                            ),
                          ],
                        ))),
              ),
              SizedBox(
                height: 20,
              ),
              Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                Container(
                  height: 60,
                  width: 180,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment(0.0, 0.0),
                        end: Alignment(1.0, 0.0),
                        stops: [
                          0.1,
                          0.5
                        ],
                        colors: [
                          Color(0xffFFFFFF),
                          Color(0xffFFFFFF),
                        ]),
                    borderRadius: BorderRadius.all(const Radius.circular(13.0)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset(
                        "assets/images/arrow.png",
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Text("Get Direction",
                          style: TextStyle(
                            fontFamily: 'Inter',
                            color: Color(0xff515AC5),
                            fontWeight: FontWeight.w400,
                            fontStyle: FontStyle.normal,
                            fontSize: 20,
                          )),
                    ],
                  ),
                ),
                Container(
                  height: 60,
                  width: 180,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                        stops: [
                          0.0,
                          0.2
                        ],
                        colors: [
                          Color(0xff3F46BD),
                          Color(0xff417DE8),
                        ]),
                    borderRadius: BorderRadius.all(const Radius.circular(13.0)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("|||",
                          style: TextStyle(
                            fontFamily: 'Inter',
                            color: Color(0xffFFFFFF),
                            fontWeight: FontWeight.w400,
                            fontStyle: FontStyle.normal,
                            fontSize: 20,
                          )),
                      SizedBox(
                        width: 10,
                      ),
                      Text("Scan Your Bill",
                          style: TextStyle(
                            fontFamily: 'Inter',
                            color: Color(0xffFFFFFF),
                            fontWeight: FontWeight.w400,
                            fontStyle: FontStyle.normal,
                            fontSize: 18,
                          )),
                    ],
                  ),
                )
              ]),
              SizedBox(
                height: 20,
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Image.asset(
                  "assets/images/summersale.png",
                ),
              ),
              Column(
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                        child: Text("Best Offers",
                            style: TextStyle(
                              fontFamily: 'Inter',
                              color: Color(0xff000000),
                              fontWeight: FontWeight.w600,
                              fontStyle: FontStyle.normal,
                              fontSize: 20,
                            )),
                      ),
                    ),
                  ),
                ],
              ),
            ]))));
  }
}
