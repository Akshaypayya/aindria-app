import 'package:aindriya_testapp/view/otp_verification.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:simple_gradient_text/simple_gradient_text.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key, required String title}) : super(key: key);

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  // final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  //
  // final TextEditingController controller = TextEditingController();
var size, height, width;
  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    height = size.height;
    width = size.width;
    return Center(
      child: Container(
        decoration:  BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
                stops: [0.9,1.2],
                colors: [
                  Theme.of(context).primaryColor,
                  Theme.of(context).colorScheme.secondary,
                ])),
        child: Scaffold(
            backgroundColor: Colors.transparent,
            body: SingleChildScrollView(
              child: Column(
                children: [
                  SizedBox(height: 117),
                  GradientText("Wonder App",
                  style: TextStyle(
                    fontFamily: 'Jost',
                    fontWeight: FontWeight.w700,
                    fontStyle: FontStyle.normal,
                    fontSize: 38,
                  ),
                    colors: [
                      Color(0xff3F46BD),
                      Color(0xff417DE8),
                    ],),
                  SizedBox(height: 81),
                  Text("Login",
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontStyle: FontStyle.normal,
                      fontWeight: FontWeight.w700,
                      fontSize: 28,
                      color: Colors.black
                    ),),
                  SizedBox(height:36),
                  SizedBox(height:16),
                  Text("Enter your phone number",
                    style: TextStyle(
                        fontFamily: 'Roboto',
                        fontStyle: FontStyle.normal,
                        fontWeight: FontWeight.w300,
                        fontSize: 16,
                        color: Color(0xff888888),
                    ),),
                  SizedBox(height: 16),
                  Padding(
                    padding:  EdgeInsets.symmetric(horizontal: 20),
                    child: Container(
                      height: 50,
                      width: 388,
                      decoration:  BoxDecoration(
                          gradient: LinearGradient(
                              begin: Alignment(0.0, 0.0),
                              end: Alignment(1.0, 0.0),
                              stops: [0.1,0.5],
                              colors: [
                                Color(0xffFFFFFF),
                                Color(0xffFFFFFF),
                              ]),
                        borderRadius: BorderRadius.all(const Radius.circular(13.0)),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(5.0),
                        child: Row(
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(15),
                                child: Image.asset("assets/images/indflag.png",height: 20,width: 30)),
                            SizedBox(width:5),
                            Text("+91",style: TextStyle(
                              fontFamily: 'Roboto',
                              fontStyle: FontStyle.normal,
                              fontSize: 20,
                            ),),
                            SizedBox(width:10),
                            Text("|",style: TextStyle(
                              fontFamily: 'Roboto',
                              fontStyle: FontStyle.normal,
                              color: Color(0xffD9D9D9),
                              fontSize: 25,),),
                              ],
                              ),
                      ),
                          ),
                  ),
                  SizedBox(height:62),
                Image.asset(
                  "assets/images/zxcxzx1.png",
                  height: 229,
                  width: 292,
                  fit: BoxFit.fill,
                ),
                SizedBox(height:59),
          Text("By clicking login, you agree to our terms and policies",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: 'Roboto',
                fontStyle: FontStyle.normal,
                fontWeight: FontWeight.w300,
                fontSize: 14,
                color: Color(0xff000000),
              )),
          SizedBox(height: 15),
          Container(
            height: 50,
            width: 189,
            decoration:BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                stops: [0.0, 3.9],
                colors: [Color(0xff3F46BD),Color(0xff417DE8)],
              ),
              borderRadius: BorderRadius.circular(9.51),
            ),
            child: ElevatedButton(
              style:ButtonStyle(
                shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                  RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
                //minimumSize: MaterialStateProperty.all(const Size(50, 50)),
                backgroundColor: MaterialStateProperty.all(Colors.transparent),
                shadowColor: MaterialStateProperty.all(Colors.transparent),
              ),
              child: Padding(
                padding:
                EdgeInsets.fromLTRB(40, 10, 40, 10),
                child: GradientText(
                  'LOGIN',
                  style: TextStyle(
                      fontFamily: 'Montserrat',
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.white
                  ),
                  colors: [
                    Color(0xffFFFFFF),
                    Color(0xffFFFFFF),],
                ),
              ),
              onPressed: () {
                  Get.to(()=>Otp());
                //};
              },
            ),
          ),
                  SizedBox(height: 129),

                      ],
                    ),
                  ),


              ),
      ),
    );
  }
}
