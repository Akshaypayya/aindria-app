import 'package:aindriya_testapp/navigation/navigator.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:simple_gradient_text/simple_gradient_text.dart';

class Otp extends StatefulWidget {
  Otp({Key? key}) : super(key: key);
  @override
  State<Otp> createState() => _OtpState();
}

class _OtpState extends State<Otp> {
  var size, height, width;
  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    height = size.height;
    width = size.width;
    return Container(
        decoration: BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
                stops: [0.5,1.2],
                colors: [
                  Theme.of(context).primaryColor,
              Theme.of(context).colorScheme.secondary,
            ])),
        child: Scaffold(
          backgroundColor: Colors.transparent,
          body: SingleChildScrollView(
            child: Column(
              children: [
                SizedBox(height: 219),
                Text("OTP Verification",
                  style: TextStyle(
                      fontFamily: 'Roboto',
                      fontStyle: FontStyle.normal,
                      fontWeight: FontWeight.bold,
                      fontSize: 28,
                      color: Colors.black
                  ),),
                SizedBox(height: 36),
                Text("Enter the OTP recieved on your phone",
                  style: TextStyle(
                    fontFamily: 'Roboto',
                    fontStyle: FontStyle.normal,
                    fontWeight: FontWeight.w700,
                    fontSize: 16,
                    color: Color(0xff888888),
                  ),),
                SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Container(
                      height: 50,
                      width: 60,
                      decoration:  BoxDecoration(
                        gradient: LinearGradient(
                            begin: Alignment(0.0, 0.0),
                            end: Alignment(1, -0.003),
                            stops: [0.1,0.5],
                            colors: [
                              Color(0xffFFFFFF),
                              Color(0xffFFFFFF),
                            ]),
                        borderRadius: BorderRadius.all(const Radius.circular(13.0)),
                      ),
                    ),
                    Container(
                      height: 50,
                      width: 60,
                      decoration:  BoxDecoration(
                        gradient: LinearGradient(
                            begin: Alignment(0.0, 0.0),
                            end: Alignment(1, -0.003),
                            stops: [0.1,0.5],
                            colors: [
                              Color(0xffFFFFFF),
                              Color(0xffFFFFFF),
                            ]),
                        borderRadius: BorderRadius.all(const Radius.circular(13.0)),
                      ),
                    ),
                    Container(
                      height: 50,
                      width: 60,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                            begin: Alignment(0.0, 0.0),
                            end: Alignment(1, -0.003),
                            stops: [
                              0.1,
                              0.5
                            ],
                            colors: [
                              Color(0xffFFFFFF),
                              Color(0xffFFFFFF),
                            ]),
                        borderRadius:
                            BorderRadius.all(const Radius.circular(13.0)),
                      ),
                    ),
                    Container(
                      height: 50,
                      width: 60,
                      decoration:  BoxDecoration(
                        gradient: LinearGradient(
                            begin: Alignment(0.0, 0.0),
                            end: Alignment(1, -0.003),
                            stops: [0.1,0.5],
                            colors: [
                              Color(0xffFFFFFF),
                              Color(0xffFFFFFF),
                            ]),
                        borderRadius: BorderRadius.all(const Radius.circular(13.0)),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 17),
                Container(
                  child: Center(
                    child: RichText(
                      text:TextSpan(
                        text:"Didn't recieve OTP? ",
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontStyle: FontStyle.normal,
                        fontWeight: FontWeight.w300,
                        fontSize: 16,
                        color: Color(0xff888888),
                      ),
                      children: <TextSpan>[
                        TextSpan(
                          text: 'Resent',
                      style: TextStyle(
                      fontFamily: 'Roboto',
                        fontStyle: FontStyle.normal,
                        fontWeight: FontWeight.w300,
                        fontSize: 16,
                        color: Color(0xff3E4CCA),
                      ),
                          recognizer: TapGestureRecognizer()
                            ..onTap = (){}
                          )
                      ]
                      ),
                ),
                  ),
                ),
                SizedBox(height: 30),

              Column(
                children: [
                  Image.asset("assets/images/zxcxzx2.png",//height: 252,width: 299,
                    ),
                  Container(
                      height: 11,
                      width: 155,
                      decoration: BoxDecoration(
                          color: Colors.transparent,
                          boxShadow: [BoxShadow(
                              blurRadius: 30,
                              color:Color(0xff414141) )])
                  ),
                ],
              ),
          SizedBox(height: 87),
                Container(
                  height: 50,
                  width: 189,
                  decoration:BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      stops: [0.0, 9.9],
                      colors: [Color(0xff3F46BD),Color(0xff417DE8)],
                    ),
                    borderRadius: BorderRadius.circular(9.51),
                  ),
                  child: ElevatedButton(
                    style:ButtonStyle(
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                        RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(5.51),
                        ),
                      ),
                      //minimumSize: MaterialStateProperty.all(const Size(50, 50)),
                      backgroundColor: MaterialStateProperty.all(Colors.transparent),
                      shadowColor: MaterialStateProperty.all(Colors.transparent),
                    ),
                    child: Padding(
                      padding:
                      EdgeInsets.fromLTRB(40, 10, 40, 10),
                      child: GradientText(
                        'Verify',
                        style: TextStyle(
                            fontFamily: 'Montserrat',
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.white
                        ),
                        colors: [
                          Color(0xffFFFFFF),
                          Color(0xffFFFFFF),],
                      ),
                    ),
                    onPressed: () {
                      Get.to(()=>Navigationpage());
                      //};
                    },
                  ),
                ),

              ],
            ),
          ),
        ));
  }
}
